# Pocket Option OTC Bot

## Overview

This is a full-stack web application that generates and displays live trading signals for Pocket Option OTC (Over-The-Counter) currency pairs. The system analyzes market data using technical indicators (Bollinger Bands, RSI, Williams %R, MACD, Stochastic, EMA) to generate high-confidence trading signals and delivers them through a real-time dashboard and Telegram notifications.

The application uses a React frontend with shadcn/ui components styled in a cyberpunk/fintech theme, an Express.js backend for signal generation and API endpoints, and PostgreSQL (via Neon) for persistent storage of signals and statistics.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Tooling:**
- React 18 with TypeScript for type safety
- Vite as the build tool and development server
- Wouter for lightweight client-side routing
- TanStack Query (React Query) for server state management and data fetching

**UI Component System:**
- shadcn/ui component library (Radix UI primitives)
- Tailwind CSS with custom cyberpunk/fintech color scheme
- Framer Motion for animations and transitions
- Custom fonts: Orbitron (display), Rajdhani (sans), Inter (body)

**State Management:**
- React Query handles all server state (signals, stats, market data)
- Local component state with React hooks
- No global state management library needed due to React Query's caching

**Design Decisions:**
- Single-page application with dashboard as the main view
- Real-time data polling via React Query (automatic refetching)
- Responsive design with mobile-first approach
- Dark theme with neon green/cyan accents for a trading terminal aesthetic

### Backend Architecture

**Framework:**
- Express.js server with TypeScript
- HTTP server (no WebSocket implementation currently)
- RESTful API design pattern

**Signal Generation System:**
- Scheduled signal generation using setInterval (runs every 5 minutes)
- Multi-indicator technical analysis combining:
  - RSI (Relative Strength Index) for momentum
  - Williams %R for overbought/oversold conditions
  - Bollinger Bands for volatility
  - MACD for trend direction
  - Stochastic oscillator for momentum confirmation
  - EMA (Fast/Slow) for trend validation
- High precision mode filters signals based on indicator confluence
- Targets next 5-minute candle timing with 2-minute preparation window

**API Endpoints:**
- `GET /api/signals` - Retrieve historical signals with optional limit
- `GET /api/stats` - Get win/loss statistics
- `GET /api/market-data` - Fetch current market prices for OTC pairs
- `POST /api/generate-signal` - Manually trigger signal generation

**Module Structure:**
- `signal-generator.ts` - Core indicator calculation and signal logic
- `signal-scheduler.ts` - Automated signal generation on 5-minute intervals
- `storage.ts` - Database abstraction layer
- `telegram.ts` - Telegram bot integration for notifications
- `routes.ts` - API route handlers
- `vite.ts` - Development server integration with Vite HMR

### Data Storage

**Database:**
- PostgreSQL via Neon serverless database
- Drizzle ORM for type-safe database operations
- Schema-first approach with Drizzle-Zod for validation

**Database Schema:**

**Signals Table:**
- Stores each generated trading signal
- Fields: signalId, pair, direction (BUY/SELL), confidence, payout, entry/exit prices, indicators (JSONB), status, timestamps
- Tracks signal lifecycle from generation through expiry

**Stats Table:**
- Maintains cumulative and daily win/loss statistics
- Auto-initialized on first access
- Fields: wins, losses, todayWins, todayLosses, lastUpdated

**Data Flow:**
1. Signal generation creates record in database
2. Telegram notification sent asynchronously
3. Frontend polls for updates via React Query
4. Signal status updates persist to database
5. Stats automatically recalculated

### External Dependencies

**Database Service:**
- Neon Serverless PostgreSQL
- Connection via `@neondatabase/serverless` with WebSocket support
- Drizzle ORM for migrations and queries
- Environment variable: `DATABASE_URL`

**Telegram Integration:**
- Telegram Bot API for push notifications
- Sends formatted signal messages to specified channel/chat
- Environment variables: `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHANNEL_ID`
- Fallback behavior: continues operation if credentials missing

**Replit Platform:**
- Vite plugins for Replit-specific features (cartographer, dev banner)
- Runtime error overlay for development
- Meta image plugin for OpenGraph tags
- Deployment domain detection for proper asset URLs

**Third-Party Libraries:**
- Radix UI primitives for accessible components
- date-fns for timestamp formatting
- zod for runtime validation
- nanoid for unique ID generation
- ws (WebSocket) for Neon database connections

**Development Dependencies:**
- TypeScript for type checking
- ESBuild for server bundling
- PostCSS with Tailwind CSS
- Vite for client bundling and HMR

**Currency Pairs:**
- Predefined list of 12 high-payout OTC pairs (EURUSD_OTC, GBPUSD_OTC, etc.)
- Static payout percentages per pair (92-95%)
- No external market data API currently integrated (uses simulated data)