CREATE TABLE "market_data" (
	"id" serial PRIMARY KEY NOT NULL,
	"pair" text NOT NULL,
	"payout" integer NOT NULL,
	"price" double precision NOT NULL,
	"change" double precision NOT NULL,
	"timestamp" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "signals" (
	"id" serial PRIMARY KEY NOT NULL,
	"signal_id" text NOT NULL,
	"pair" text NOT NULL,
	"direction" text NOT NULL,
	"confidence" integer NOT NULL,
	"payout" integer NOT NULL,
	"entry_price" double precision,
	"exit_price" double precision,
	"indicators" jsonb NOT NULL,
	"status" text DEFAULT 'PENDING' NOT NULL,
	"timestamp" timestamp DEFAULT now() NOT NULL,
	"expiry_time" timestamp NOT NULL,
	"sent_to_telegram" boolean DEFAULT false NOT NULL,
	CONSTRAINT "signals_signal_id_unique" UNIQUE("signal_id")
);
--> statement-breakpoint
CREATE TABLE "ssid_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"ssid" text NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"last_updated" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "stats" (
	"id" serial PRIMARY KEY NOT NULL,
	"wins" integer DEFAULT 0 NOT NULL,
	"losses" integer DEFAULT 0 NOT NULL,
	"today_wins" integer DEFAULT 0 NOT NULL,
	"today_losses" integer DEFAULT 0 NOT NULL,
	"last_updated" timestamp DEFAULT now() NOT NULL
);
