#!/usr/bin/env python3
"""
Pocket Option API Connection Service
Connects to Pocket Option using SSID for real-time data and signal tracking
"""

import asyncio
import json
import os
import sys
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
import websockets

POCKET_OPTION_WS_URL = "wss://api-l.po.market/socket.io/?EIO=4&transport=websocket"
POCKET_OPTION_WS_DEMO = "wss://demo-api-eu.po.market/socket.io/?EIO=4&transport=websocket"

class PocketOptionConnection:
    def __init__(self, ssid: str, is_demo: bool = True):
        self.ssid = ssid
        self.is_demo = is_demo
        self.ws_url = POCKET_OPTION_WS_DEMO if is_demo else POCKET_OPTION_WS_URL
        self.websocket = None
        self.connected = False
        self.candle_data: Dict[str, List[Dict]] = {}
        self.current_prices: Dict[str, float] = {}
        
    async def connect(self) -> bool:
        """Connect to Pocket Option WebSocket"""
        try:
            print(f"[PO-API] Connecting to Pocket Option {'Demo' if self.is_demo else 'Real'}...")
            self.websocket = await websockets.connect(
                self.ws_url,
                ping_interval=20,
                ping_timeout=10
            )
            
            # Wait for connection acknowledgment
            response = await self.websocket.recv()
            print(f"[PO-API] Server response: {response[:100]}...")
            
            # Send authentication
            auth_message = self.ssid
            await self.websocket.send(auth_message)
            print("[PO-API] Auth message sent")
            
            # Wait for auth response
            auth_response = await asyncio.wait_for(self.websocket.recv(), timeout=10)
            print(f"[PO-API] Auth response: {auth_response[:100]}...")
            
            self.connected = True
            print("[PO-API] Connected successfully!")
            return True
            
        except Exception as e:
            print(f"[PO-API] Connection error: {e}")
            self.connected = False
            return False
    
    async def subscribe_to_asset(self, asset: str) -> bool:
        """Subscribe to real-time updates for an asset"""
        if not self.connected or not self.websocket:
            return False
            
        try:
            # Subscribe message format for Pocket Option
            subscribe_msg = f'42["subscribeMessage","{asset}",1]'
            await self.websocket.send(subscribe_msg)
            print(f"[PO-API] Subscribed to {asset}")
            return True
        except Exception as e:
            print(f"[PO-API] Subscribe error: {e}")
            return False
    
    async def get_candles(self, asset: str, timeframe: int = 60, count: int = 100) -> List[Dict]:
        """Get historical candles for an asset"""
        if not self.connected or not self.websocket:
            return []
            
        try:
            # Request candles
            request_msg = f'42["sendMessage","candles",{{"asset":"{asset}","period":{timeframe},"count":{count}}}]'
            await self.websocket.send(request_msg)
            
            # Wait for response
            response = await asyncio.wait_for(self.websocket.recv(), timeout=10)
            
            # Parse candle data
            if "candles" in response:
                data = json.loads(response[2:])  # Remove "42" prefix
                return data[1] if len(data) > 1 else []
            return []
            
        except Exception as e:
            print(f"[PO-API] Get candles error: {e}")
            return []
    
    async def get_current_price(self, asset: str) -> Optional[float]:
        """Get current price for an asset"""
        return self.current_prices.get(asset)
    
    async def listen_for_updates(self):
        """Listen for real-time price updates"""
        if not self.connected or not self.websocket:
            return
            
        try:
            async for message in self.websocket:
                try:
                    if message.startswith("42"):
                        data = json.loads(message[2:])
                        event_type = data[0] if data else None
                        
                        if event_type == "candle":
                            # Update candle data
                            candle_info = data[1]
                            asset = candle_info.get("asset")
                            if asset:
                                self.current_prices[asset] = candle_info.get("close", 0)
                                
                        elif event_type == "price":
                            # Update current price
                            price_info = data[1]
                            asset = price_info.get("asset")
                            if asset:
                                self.current_prices[asset] = price_info.get("price", 0)
                                
                except json.JSONDecodeError:
                    pass
                    
        except Exception as e:
            print(f"[PO-API] Listen error: {e}")
            self.connected = False
    
    async def close(self):
        """Close the connection"""
        if self.websocket:
            await self.websocket.close()
        self.connected = False
        print("[PO-API] Connection closed")


class SignalTracker:
    """Track signal outcomes and calculate accuracy"""
    
    def __init__(self):
        self.signals: List[Dict] = []
        self.wins = 0
        self.losses = 0
        
    def add_signal(self, signal_id: str, pair: str, direction: str, 
                   entry_price: float, entry_time: datetime, expiry_minutes: int = 5):
        """Add a new signal to track"""
        self.signals.append({
            "id": signal_id,
            "pair": pair,
            "direction": direction,
            "entry_price": entry_price,
            "entry_time": entry_time,
            "expiry_time": entry_time + timedelta(minutes=expiry_minutes),
            "exit_price": None,
            "result": None,
            "tracked": False
        })
        print(f"[Tracker] Added signal: {pair} {direction} @ {entry_price}")
        
    def update_signal_result(self, signal_id: str, exit_price: float) -> Optional[str]:
        """Update signal with exit price and determine result"""
        for signal in self.signals:
            if signal["id"] == signal_id and not signal["tracked"]:
                signal["exit_price"] = exit_price
                signal["tracked"] = True
                
                # Determine win/loss
                if signal["direction"] == "BUY":
                    signal["result"] = "WIN" if exit_price > signal["entry_price"] else "LOSS"
                else:  # SELL
                    signal["result"] = "WIN" if exit_price < signal["entry_price"] else "LOSS"
                
                if signal["result"] == "WIN":
                    self.wins += 1
                else:
                    self.losses += 1
                    
                print(f"[Tracker] Signal {signal_id[:8]}: {signal['result']} ({signal['entry_price']:.5f} -> {exit_price:.5f})")
                return signal["result"]
        return None
    
    def get_accuracy(self) -> float:
        """Calculate win rate percentage"""
        total = self.wins + self.losses
        if total == 0:
            return 0.0
        return (self.wins / total) * 100
    
    def get_stats(self) -> Dict:
        """Get tracking statistics"""
        return {
            "wins": self.wins,
            "losses": self.losses,
            "total": self.wins + self.losses,
            "accuracy": self.get_accuracy(),
            "pending": len([s for s in self.signals if not s["tracked"]])
        }


async def run_continuous(ssid: str):
    """Run continuous connection and output prices"""
    print("\n" + "="*50)
    print("POCKET OPTION LIVE CONNECTION")
    print("="*50)
    
    connection = PocketOptionConnection(ssid, is_demo=True)
    success = await connection.connect()
    
    if success:
        print("\n[LIVE] Connected successfully!")
        
        # Subscribe to popular OTC pairs
        assets = ["EURUSD_otc", "GBPUSD_otc", "USDJPY_otc", "AUDUSD_otc"]
        for asset in assets:
            await connection.subscribe_to_asset(asset)
            await asyncio.sleep(0.5)
        
        print("[LIVE] Listening for price updates...")
        
        # Listen continuously and output prices every 5 seconds
        while connection.connected:
            try:
                await asyncio.wait_for(connection.listen_for_updates(), timeout=5)
            except asyncio.TimeoutError:
                if connection.current_prices:
                    print(f"Prices received: {connection.current_prices}")
            except Exception as e:
                print(f"[LIVE] Error: {e}")
                break
        
        await connection.close()
    else:
        print("\n[LIVE] Connection failed!")
        
    print("="*50 + "\n")

async def test_connection(ssid: str):
    """Test the Pocket Option connection"""
    print("\n" + "="*50)
    print("POCKET OPTION CONNECTION TEST")
    print("="*50)
    
    connection = PocketOptionConnection(ssid, is_demo=True)
    success = await connection.connect()
    
    if success:
        print("\n[TEST] Connection successful!")
        print("[TEST] Subscribing to EURUSD_otc...")
        await connection.subscribe_to_asset("EURUSD_otc")
        
        # Listen for a few seconds
        print("[TEST] Listening for price updates (10 seconds)...")
        try:
            await asyncio.wait_for(connection.listen_for_updates(), timeout=10)
        except asyncio.TimeoutError:
            pass
        
        print(f"\n[TEST] Prices received: {connection.current_prices}")
        await connection.close()
    else:
        print("\n[TEST] Connection failed!")
        
    print("="*50 + "\n")


if __name__ == "__main__":
    # Get SSID from environment or command line
    ssid = os.environ.get("POCKET_OPTION_SSID", "")
    
    if not ssid and len(sys.argv) > 1:
        ssid = sys.argv[1]
    
    if not ssid:
        print("Error: POCKET_OPTION_SSID environment variable or command line argument required")
        print("Usage: python pocket_option_api.py '<your_ssid>' [--continuous]")
        sys.exit(1)
    
    # Always run in continuous mode for live prices
    asyncio.run(run_continuous(ssid))
