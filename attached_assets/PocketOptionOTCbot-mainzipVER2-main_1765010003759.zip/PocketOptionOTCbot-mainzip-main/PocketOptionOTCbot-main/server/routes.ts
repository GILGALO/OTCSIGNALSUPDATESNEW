import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateMarketData } from "./signal-generator";
import { sendSignalToTelegram } from "./telegram";
import { generateAndSendSignal, setAutoGeneration, isAutoGenerationEnabled } from "./signal-scheduler";
import { randomUUID } from "crypto";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Get all signals
  app.get("/api/signals", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const signals = await storage.getSignals(limit);
      
      // Add timing info for display
      const enrichedSignals = signals.map(signal => {
        const enterTime = new Date(signal.timestamp);
        const prepareTime = new Date(enterTime.getTime() - 2 * 60000);
        
        return {
          ...signal,
          prepareTime: prepareTime.toISOString(),
          enterTime: enterTime.toISOString(),
        };
      });
      
      res.json(enrichedSignals);
    } catch (error) {
      console.error("Error fetching signals:", error);
      res.status(500).json({ error: "Failed to fetch signals" });
    }
  });

  // Get current stats
  app.get("/api/stats", async (req, res) => {
    try {
      let stats = await storage.getStats();
      if (!stats) {
        stats = await storage.initializeStats();
      }
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // Generate a new signal manually (triggers immediately + sends to Telegram)
  app.post("/api/signals/generate", async (req, res) => {
    try {
      const { pocketOptionService } = req.app.locals;
      const livePrices = pocketOptionService?.isConnected ? pocketOptionService.getAllPrices() : undefined;
      
      await generateAndSendSignal(livePrices);
      
      // Get the latest signal
      const signals = await storage.getSignals(1);
      const latestSignal = signals[0];
      
      res.json({ 
        signal: latestSignal, 
        telegramSent: latestSignal?.sentToTelegram || false 
      });
    } catch (error) {
      console.error("Error generating signal:", error);
      res.status(500).json({ error: "Failed to generate signal" });
    }
  });

  // Get market data
  app.get("/api/market", async (req, res) => {
    try {
      const marketData = generateMarketData();
      res.json(marketData);
    } catch (error) {
      console.error("Error fetching market data:", error);
      res.status(500).json({ error: "Failed to fetch market data" });
    }
  });

  // Update signal status (for tracking wins/losses)
  app.patch("/api/signals/:signalId/status", async (req, res) => {
    try {
      const { signalId } = req.params;
      const { status, exitPrice } = req.body;

      await storage.updateSignalStatus(signalId, status, exitPrice);

      // Update stats if signal won or lost
      if (status === "WON" || status === "LOST") {
        const currentStats = await storage.getStats();
        if (currentStats) {
          const updates: any = {};
          if (status === "WON") {
            updates.wins = currentStats.wins + 1;
            updates.todayWins = currentStats.todayWins + 1;
          } else {
            updates.losses = currentStats.losses + 1;
            updates.todayLosses = currentStats.todayLosses + 1;
          }
          await storage.updateStats(updates);
        }
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error updating signal status:", error);
      res.status(500).json({ error: "Failed to update signal status" });
    }
  });

  // Get live prices from Pocket Option
  app.get("/api/live-prices", async (req, res) => {
    try {
      const { pocketOptionService } = req.app.locals;
      
      if (!pocketOptionService) {
        return res.status(503).json({ 
          error: "Live price service not initialized",
          message: "Set POCKET_OPTION_SSID environment variable to enable live prices"
        });
      }

      const prices = pocketOptionService.getAllPrices();
      res.json({ 
        prices,
        timestamp: new Date().toISOString(),
        connected: pocketOptionService.isConnected
      });
    } catch (error) {
      console.error("Error fetching live prices:", error);
      res.status(500).json({ error: "Failed to fetch live prices" });
    }
  });

  // Toggle auto-generation
  app.post("/api/auto-generation/toggle", async (req, res) => {
    try {
      const { enabled } = req.body;
      setAutoGeneration(enabled);
      res.json({ 
        success: true, 
        autoGenerationEnabled: enabled 
      });
    } catch (error) {
      console.error("Error toggling auto-generation:", error);
      res.status(500).json({ error: "Failed to toggle auto-generation" });
    }
  });

  // Get auto-generation status
  app.get("/api/auto-generation/status", (req, res) => {
    res.json({ 
      autoGenerationEnabled: isAutoGenerationEnabled() 
    });
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "ok", 
      timestamp: new Date().toISOString(),
      scheduler: "running",
      autoGenerationEnabled: isAutoGenerationEnabled()
    });
  });

  // SSID Settings endpoints
  app.get("/api/settings/ssid", async (req, res) => {
    try {
      const ssidData = await storage.getSsidSettings();
      res.json(ssidData || { ssid: null, status: "unknown", lastUpdated: null });
    } catch (error) {
      console.error("Error fetching SSID settings:", error);
      res.status(500).json({ error: "Failed to fetch SSID settings" });
    }
  });

  app.post("/api/settings/ssid", async (req, res) => {
    try {
      const { ssid } = req.body;
      
      if (!ssid || typeof ssid !== "string" || ssid.trim().length === 0) {
        return res.status(400).json({ error: "Invalid SSID" });
      }

      // Save SSID to database
      await storage.saveSsidSettings(ssid.trim());

      // Import PocketOptionService dynamically
      const { PocketOptionService } = await import("./pocket-option-service");

      // Disconnect old service if exists
      const { pocketOptionService } = req.app.locals;
      if (pocketOptionService) {
        console.log("[SSID-Update] Disconnecting old service...");
        pocketOptionService.disconnect();
      }

      // Create new service with updated SSID
      console.log("[SSID-Update] Creating new service with SSID:", ssid.trim().substring(0, 8) + "...");
      const newService = new PocketOptionService(ssid.trim());
      req.app.locals.pocketOptionService = newService;

      // Set up event handlers
      newService.on('connected', () => {
        console.log('[SSID-Update] ✓ Pocket Option connected - Live prices available');
      });

      newService.on('disconnected', () => {
        console.log('[SSID-Update] ⚠ Pocket Option disconnected - Reconnecting...');
        setTimeout(() => newService.connect(), 5000);
      });

      // Connect to Pocket Option
      const connected = await newService.connect();
      
      res.json({ 
        success: true, 
        status: connected ? "active" : "failed",
        message: connected ? "SSID updated and connected successfully" : "SSID saved but connection failed - check console"
      });
    } catch (error) {
      console.error("Error saving SSID:", error);
      res.status(500).json({ error: "Failed to save SSID" });
    }
  });

  app.get("/api/settings/ssid/status", async (req, res) => {
    try {
      const { pocketOptionService } = req.app.locals;
      const ssidData = await storage.getSsidSettings();
      
      let status = "unknown";
      
      if (pocketOptionService && pocketOptionService.isConnected) {
        status = "active";
        console.log("[SSID-Status] Service connected - Status: active");
      } else if (pocketOptionService && !pocketOptionService.isConnected) {
        status = "expired";
        console.log("[SSID-Status] Service exists but not connected - Status: expired");
      } else if (ssidData && ssidData.lastUpdated) {
        // Check if SSID is older than 48 hours
        const hoursSinceUpdate = (Date.now() - new Date(ssidData.lastUpdated).getTime()) / (1000 * 60 * 60);
        status = hoursSinceUpdate > 48 ? "expired" : "unknown";
        console.log(`[SSID-Status] No service, ${hoursSinceUpdate.toFixed(1)}h since update - Status: ${status}`);
      }

      res.json({ 
        status,
        connected: pocketOptionService?.isConnected || false,
        ssidConfigured: !!ssidData?.ssid
      });
    } catch (error) {
      console.error("Error checking SSID status:", error);
      res.status(500).json({ error: "Failed to check SSID status" });
    }
  });

  return httpServer;
}
