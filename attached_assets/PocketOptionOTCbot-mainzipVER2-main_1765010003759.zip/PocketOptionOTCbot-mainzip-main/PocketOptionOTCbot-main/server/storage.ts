import { type Signal, type InsertSignal, type Stats, signals, stats } from "@shared/schema";
import { neonConfig, Pool } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-serverless";
import { eq, desc } from "drizzle-orm";
import ws from "ws";
import { ssidSettings } from "@shared/schema";

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle({ client: pool });

export interface IStorage {
  createSignal(signal: InsertSignal): Promise<Signal>;
  getSignals(limit?: number): Promise<Signal[]>;
  getSignalById(signalId: string): Promise<Signal | undefined>;
  updateSignalStatus(signalId: string, status: string, exitPrice?: number): Promise<void>;
  markSignalAsSentToTelegram(signalId: string): Promise<void>;

  getStats(): Promise<Stats | undefined>;
  updateStats(updates: Partial<Stats>): Promise<Stats>;
  initializeStats(): Promise<Stats>;

  getSsidSettings(): Promise<any | null>;
  saveSsidSettings(ssid: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async createSignal(insertSignal: InsertSignal): Promise<Signal> {
    const [signal] = await db.insert(signals).values(insertSignal).returning();
    return signal;
  }

  async getSignals(limit: number = 50): Promise<Signal[]> {
    return await db.select().from(signals).orderBy(desc(signals.timestamp)).limit(limit);
  }

  async getSignalById(signalId: string): Promise<Signal | undefined> {
    const [signal] = await db.select().from(signals).where(eq(signals.signalId, signalId));
    return signal;
  }

  async updateSignalStatus(signalId: string, status: string, exitPrice?: number): Promise<void> {
    const updates: any = { status };
    if (exitPrice !== undefined) {
      updates.exitPrice = exitPrice;
    }
    await db.update(signals).set(updates).where(eq(signals.signalId, signalId));
  }

  async markSignalAsSentToTelegram(signalId: string): Promise<void> {
    await db.update(signals).set({ sentToTelegram: true }).where(eq(signals.signalId, signalId));
  }

  async updateSignalResult(signalId: string, exitPrice: number, result: "WIN" | "LOSS"): Promise<void> {
    await db.update(signals).set({ 
      exitPrice, 
      status: result 
    }).where(eq(signals.signalId, signalId));
  }

  async getStats(): Promise<Stats | undefined> {
    const [stat] = await db.select().from(stats).limit(1);
    return stat;
  }

  async updateStats(updates: Partial<Stats>): Promise<Stats> {
    const currentStats = await this.getStats();
    if (!currentStats) {
      return await this.initializeStats();
    }
    const [updatedStats] = await db
      .update(stats)
      .set({ ...updates, lastUpdated: new Date() })
      .where(eq(stats.id, currentStats.id))
      .returning();
    return updatedStats;
  }

  async initializeStats(): Promise<Stats> {
    const [newStats] = await db
      .insert(stats)
      .values({ wins: 0, losses: 0, todayWins: 0, todayLosses: 0 })
      .returning();
    return newStats;
  }

  async getSsidSettings() {
    const result = await db.select().from(ssidSettings).limit(1);
    return result[0] || null;
  }

  async saveSsidSettings(ssid: string) {
    const existing = await this.getSsidSettings();

    if (existing) {
      await db.update(ssidSettings)
        .set({ 
          ssid, 
          lastUpdated: new Date(),
          status: 'active'
        })
        .where(eq(ssidSettings.id, existing.id));
    } else {
      await db.insert(ssidSettings).values({
        ssid,
        lastUpdated: new Date(),
        status: 'active'
      });
    }
  }
}

export const storage = new DatabaseStorage();