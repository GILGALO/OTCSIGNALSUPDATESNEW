
import { spawn, ChildProcess } from 'child_process';
import { EventEmitter } from 'events';
import path from 'path';

interface PriceUpdate {
  asset: string;
  price: number;
  timestamp: number;
}

export class PocketOptionService extends EventEmitter {
  private pythonProcess: ChildProcess | null = null;
  public ssid: string;
  public isConnected: boolean = false;
  private currentPrices: Map<string, number> = new Map();
  private priceHistory: Map<string, number[]> = new Map();

  constructor(ssid: string) {
    super();
    this.ssid = ssid;
  }

  async connect(): Promise<boolean> {
    if (this.isConnected) {
      console.log('[PO-Service] Already connected');
      return true;
    }

    try {
      const scriptPath = path.join(__dirname, 'pocket_option_api.py');
      
      // Run in continuous mode
      this.pythonProcess = spawn('python3', [scriptPath, this.ssid, '--continuous']);

      this.pythonProcess.stdout?.on('data', (data) => {
        const output = data.toString();
        console.log('[PO-Service]', output);

        // Parse price updates from Python output
        if (output.includes('Prices received:')) {
          try {
            const pricesMatch = output.match(/Prices received: ({.*})/);
            if (pricesMatch) {
              const pricesStr = pricesMatch[1].replace(/'/g, '"');
              const prices = JSON.parse(pricesStr);
              
              Object.entries(prices).forEach(([asset, price]) => {
                const numPrice = Number(price);
                this.currentPrices.set(asset, numPrice);
                
                // Track price history for trend analysis
                if (!this.priceHistory.has(asset)) {
                  this.priceHistory.set(asset, []);
                }
                const history = this.priceHistory.get(asset)!;
                history.push(numPrice);
                if (history.length > 100) {
                  history.shift(); // Keep last 100 prices
                }
                
                this.emit('price', { asset, price: numPrice, timestamp: Date.now() });
              });
              
              console.log(`[PO-Service] Live prices updated: ${Object.keys(prices).length} pairs`);
            }
          } catch (e) {
            console.error('[PO-Service] Error parsing prices:', e);
          }
        }

        if (output.includes('Connected successfully')) {
          this.isConnected = true;
          this.emit('connected');
          console.log('[PO-Service] ✓ Live price feed active');
        }
      });

      this.pythonProcess.stderr?.on('data', (data) => {
        console.error('[PO-Service] Error:', data.toString());
      });

      this.pythonProcess.on('close', (code) => {
        console.log('[PO-Service] Process exited with code:', code);
        this.isConnected = false;
        this.emit('disconnected');
      });

      return true;
    } catch (error) {
      console.error('[PO-Service] Connection error:', error);
      return false;
    }
  }

  getPrice(asset: string): number | null {
    return this.currentPrices.get(asset) || null;
  }

  getAllPrices(): Record<string, number> {
    return Object.fromEntries(this.currentPrices);
  }

  getPriceHistory(asset: string): number[] {
    return this.priceHistory.get(asset) || [];
  }

  // Calculate price trend
  getPriceTrend(asset: string): 'UP' | 'DOWN' | 'NEUTRAL' {
    const history = this.getPriceHistory(asset);
    if (history.length < 10) return 'NEUTRAL';
    
    const recent = history.slice(-10);
    const avg = recent.reduce((a, b) => a + b, 0) / recent.length;
    const current = recent[recent.length - 1];
    
    if (current > avg * 1.0001) return 'UP';
    if (current < avg * 0.9999) return 'DOWN';
    return 'NEUTRAL';
  }

  disconnect(): void {
    if (this.pythonProcess) {
      this.pythonProcess.kill();
      this.pythonProcess = null;
      this.isConnected = false;
    }
  }
}
