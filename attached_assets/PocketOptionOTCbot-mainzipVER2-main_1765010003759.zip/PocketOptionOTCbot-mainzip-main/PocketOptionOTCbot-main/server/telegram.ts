interface TelegramSignal {
  pair: string;
  direction: string;
  confidence: number;
  payout: number;
  indicators: {
    rsi: number;
    williamsR: number;
    bollinger: {
      upper: number;
      lower: number;
      current: number;
    };
  };
  signalId: string;
  expiryTime: Date;
  prepareTime?: Date;
  enterTime?: Date;
}

export async function sendSignalToTelegram(signal: TelegramSignal): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHANNEL_ID;

  if (!token || !chatId) {
    console.error('Telegram credentials not configured');
    console.error('TELEGRAM_BOT_TOKEN:', token ? 'SET' : 'NOT SET');
    console.error('TELEGRAM_CHANNEL_ID:', chatId ? 'SET' : 'NOT SET');
    return false;
  }

  const message = formatSignalMessage(signal);
  const url = `https://api.telegram.org/bot${token}/sendMessage`;

  try {
    console.log(`[Telegram] Sending signal to channel ${chatId}...`);
    
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: 'HTML',
      }),
    });

    const data = await response.json();
    
    if (!response.ok) {
      console.error('[Telegram] API error:', JSON.stringify(data));
      return false;
    }

    console.log('[Telegram] Signal sent successfully:', signal.signalId);
    return true;
  } catch (error) {
    console.error('[Telegram] Failed to send signal:', error);
    return false;
  }
}

function formatSignalMessage(signal: TelegramSignal): string {
  const now = new Date();
  
  // Calculate times based on 5-minute candle timing
  const prepareTime = signal.prepareTime || new Date(now.getTime() + 2 * 60000);
  const enterTime = signal.enterTime || new Date(now.getTime() + 3 * 60000);
  const expiry = signal.expiryTime;

  const directionEmoji = signal.direction === 'BUY' ? '🟢' : '🔴';
  const directionText = signal.direction === 'BUY' ? 'CALL (UP)' : 'PUT (DOWN)';

  return `🎯 <b>POCKET OPTION SIGNAL (OTC - HIGH PRECISION)</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 <b>Asset:</b> ${signal.pair}
${directionEmoji} <b>Direction:</b> ${directionText}
⏱ <b>Expiration:</b> 5 Minutes (M5)
🌏 <b>Session:</b> Active Market

💎 <b>Confidence:</b> ${signal.confidence}% (High Precision)
💰 <b>Expected Payout:</b> ${signal.payout}%

📈 <b>Technical Analysis:</b>
• Bollinger Band: ${signal.indicators.bollinger.lower.toFixed(5)}
• RSI(14): ${signal.indicators.rsi.toFixed(2)} (Oversold ✓)
• Williams %R(14): ${signal.indicators.williamsR.toFixed(2)} (Extreme ✓)

⏰ <b>TIMING:</b>
🔔 PREPARE: ${formatTime(prepareTime)}
🎯 ENTER: ${formatTime(enterTime)}
⏳ EXPIRY: ${formatTime(expiry)}

📌 Signal ID: <code>${signal.signalId.slice(0, 8)}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚡️ <i>High Precision Mode Active</i>
🔄 <i>Next signal in ~7 minutes</i>`;
}

function formatTime(date: Date): string {
  return date.toLocaleString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
    timeZone: 'America/New_York'
  }) + ' (GMT-4)';
}
