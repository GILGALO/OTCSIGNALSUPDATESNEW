import { spawn } from "child_process";
import { storage } from "./storage";

interface SignalOutcome {
  signalId: string;
  pair: string;
  direction: "BUY" | "SELL";
  entryPrice: number;
  exitPrice: number;
  result: "WIN" | "LOSS";
  payout: number;
}

class PocketOptionBridge {
  private ssid: string | null = null;
  private connected: boolean = false;
  private pendingSignals: Map<string, {
    pair: string;
    direction: "BUY" | "SELL";
    entryPrice: number;
    entryTime: Date;
    expiryTime: Date;
    payout: number;
  }> = new Map();
  
  constructor() {
    this.ssid = process.env.POCKET_OPTION_SSID || null;
  }
  
  isConfigured(): boolean {
    return this.ssid !== null && this.ssid.length > 0;
  }
  
  async trackSignal(signalId: string, pair: string, direction: "BUY" | "SELL", 
                    entryPrice: number, expiryTime: Date, payout: number): Promise<void> {
    this.pendingSignals.set(signalId, {
      pair,
      direction,
      entryPrice,
      entryTime: new Date(),
      expiryTime,
      payout
    });
    
    console.log(`[Bridge] Tracking signal ${signalId.slice(0, 8)} - ${pair} ${direction}`);
    
    // Schedule outcome check after expiry
    const timeUntilExpiry = expiryTime.getTime() - Date.now();
    if (timeUntilExpiry > 0) {
      setTimeout(() => {
        this.checkSignalOutcome(signalId);
      }, timeUntilExpiry + 5000); // Add 5 second buffer
    }
  }
  
  private async checkSignalOutcome(signalId: string): Promise<void> {
    const signal = this.pendingSignals.get(signalId);
    if (!signal) return;
    
    try {
      // Simulate outcome for now (will be replaced with real API data)
      // In a real scenario, we would fetch the actual price from Pocket Option
      const priceChange = (Math.random() - 0.5) * 0.002;
      const exitPrice = signal.entryPrice * (1 + priceChange);
      
      // Determine win/loss
      let result: "WIN" | "LOSS";
      if (signal.direction === "BUY") {
        result = exitPrice > signal.entryPrice ? "WIN" : "LOSS";
      } else {
        result = exitPrice < signal.entryPrice ? "WIN" : "LOSS";
      }
      
      console.log(`[Bridge] Signal ${signalId.slice(0, 8)} Result: ${result}`);
      console.log(`[Bridge] Entry: ${signal.entryPrice.toFixed(5)} -> Exit: ${exitPrice.toFixed(5)}`);
      
      // Update signal in database
      await this.updateSignalResult(signalId, exitPrice, result);
      
      // Update stats
      await this.updateStats(result);
      
      this.pendingSignals.delete(signalId);
      
    } catch (error) {
      console.error(`[Bridge] Error checking outcome for ${signalId}:`, error);
    }
  }
  
  private async updateSignalResult(signalId: string, exitPrice: number, result: "WIN" | "LOSS"): Promise<void> {
    try {
      await storage.updateSignalResult(signalId, exitPrice, result);
    } catch (error) {
      console.error("[Bridge] Error updating signal result:", error);
    }
  }
  
  private async updateStats(result: "WIN" | "LOSS"): Promise<void> {
    try {
      const stats = await storage.getStats();
      if (stats) {
        if (result === "WIN") {
          await storage.updateStats({
            wins: stats.wins + 1,
            todayWins: stats.todayWins + 1
          });
        } else {
          await storage.updateStats({
            losses: stats.losses + 1,
            todayLosses: stats.todayLosses + 1
          });
        }
      }
    } catch (error) {
      console.error("[Bridge] Error updating stats:", error);
    }
  }
  
  getPendingCount(): number {
    return this.pendingSignals.size;
  }
  
  getStatus(): { configured: boolean; connected: boolean; pending: number } {
    return {
      configured: this.isConfigured(),
      connected: this.connected,
      pending: this.pendingSignals.size
    };
  }
}

export const pocketBridge = new PocketOptionBridge();
