import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Target, TrendingUp, Activity } from "lucide-react";
import { useStats } from "@/lib/api";

export function StatsPanel() {
  const { data: stats } = useStats();
  
  if (!stats) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="bg-card/40 backdrop-blur-sm border-white/5 animate-pulse">
            <CardHeader className="pb-2">
              <div className="h-4 bg-muted rounded w-20" />
            </CardHeader>
            <CardContent>
              <div className="h-8 bg-muted rounded w-12 mb-2" />
              <div className="h-3 bg-muted rounded w-24" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }
  
  const totalSignals = stats.wins + stats.losses;
  const winRate = totalSignals > 0 ? ((stats.wins / totalSignals) * 100).toFixed(1) : '0.0';

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      <Card className="bg-card/40 backdrop-blur-sm border-white/5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">Total Signals</CardTitle>
          <Target className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold font-display text-foreground">{totalSignals}</div>
          <p className="text-xs text-muted-foreground mt-1">Lifetime signals generated</p>
        </CardContent>
      </Card>

      <Card className="bg-card/40 backdrop-blur-sm border-white/5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">Win Rate</CardTitle>
          <Trophy className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold font-display text-primary text-glow">{winRate}%</div>
          <p className="text-xs text-muted-foreground mt-1">High precision mode</p>
        </CardContent>
      </Card>

      <Card className="bg-card/40 backdrop-blur-sm border-white/5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">Today's Wins</CardTitle>
          <TrendingUp className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold font-display text-foreground">{stats.todayWins}</div>
          <p className="text-xs text-muted-foreground mt-1">Losses: {stats.todayLosses}</p>
        </CardContent>
      </Card>

      <Card className="bg-card/40 backdrop-blur-sm border-white/5">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">System Status</CardTitle>
          <Activity className="h-4 w-4 text-primary animate-pulse" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold font-display text-primary">ONLINE</div>
          <p className="text-xs text-muted-foreground mt-1">WS Connected • Latency 24ms</p>
        </CardContent>
      </Card>
    </div>
  );
}
