import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CircleArrowUp, CircleArrowDown, Timer, TrendingUp, Activity, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

interface SignalIndicators {
  rsi: number;
  williamsR: number;
  bollinger: {
    upper: number;
    lower: number;
    current: number;
  };
}

export interface SignalProps {
  id: string;
  pair: string;
  direction: "BUY" | "SELL";
  timestamp: Date;
  expiry: Date;
  confidence: number;
  payout: number;
  indicators: SignalIndicators;
  status: "PENDING" | "WON" | "LOST";
  prepareTime?: Date;
  enterTime?: Date;
}

interface SignalCardProps {
  signal: SignalProps;
}

export function SignalCard({ signal }: SignalCardProps) {
  const isBuy = signal.direction === "BUY";
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="bg-card/40 backdrop-blur-sm border-primary/20 overflow-hidden hover:border-primary/40 transition-colors group relative">
        <div className={`absolute top-0 left-0 w-1 h-full ${isBuy ? 'bg-primary/50 group-hover:bg-primary' : 'bg-destructive/50 group-hover:bg-destructive'} transition-colors`} />
        
        <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0 pl-6">
          <div className="flex items-center gap-3">
            <div className={`${isBuy ? 'bg-primary/10 border-primary/20' : 'bg-destructive/10 border-destructive/20'} p-2 rounded-full border`}>
              {isBuy ? (
                <CircleArrowUp className="h-6 w-6 text-primary animate-pulse" />
              ) : (
                <CircleArrowDown className="h-6 w-6 text-destructive animate-pulse" />
              )}
            </div>
            <div>
              <CardTitle className="text-xl font-display tracking-widest">{signal.pair}</CardTitle>
              <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
                <span>M5 EXPIRY</span>
                <span className={isBuy ? "text-primary" : "text-destructive"}>•</span>
                <span>{format(signal.timestamp, "HH:mm:ss")}</span>
              </div>
            </div>
          </div>
          <Badge variant="outline" className={`${isBuy ? 'bg-primary/10 text-primary border-primary/30' : 'bg-destructive/10 text-destructive border-destructive/30'} font-mono text-lg px-3 py-1`}>
            {signal.payout}% PAYOUT
          </Badge>
        </CardHeader>

        <CardContent className="pl-6">
          <div className="grid grid-cols-2 gap-6 mb-6">
            <div className="space-y-1">
              <span className="text-[10px] uppercase tracking-widest text-muted-foreground">Direction</span>
              <div className={`flex items-center gap-2 ${isBuy ? 'text-primary' : 'text-destructive'} font-bold text-lg`}>
                {isBuy ? 'CALL' : 'PUT'} {isBuy ? <CircleArrowUp className="h-4 w-4" /> : <CircleArrowDown className="h-4 w-4" />}
              </div>
            </div>
            <div className="space-y-1">
              <span className="text-[10px] uppercase tracking-widest text-muted-foreground">Confidence</span>
              <div className="flex items-center gap-2">
                <Progress value={signal.confidence} className="h-2 w-20 bg-secondary" />
                <span className={`font-mono ${isBuy ? 'text-primary' : 'text-destructive'}`}>{signal.confidence}%</span>
              </div>
            </div>
          </div>

          <div className="space-y-3 bg-black/20 p-3 rounded-md border border-white/5">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-muted-foreground flex items-center gap-1">
                <Activity className="h-3 w-3" /> RSI (14)
              </span>
              <span className={signal.indicators.rsi < 30 || signal.indicators.rsi > 70 ? (isBuy ? "text-primary font-bold" : "text-destructive font-bold") : "text-foreground"}>
                {signal.indicators.rsi.toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-muted-foreground flex items-center gap-1">
                <TrendingUp className="h-3 w-3" /> Williams %R
              </span>
              <span className={signal.indicators.williamsR < -80 || signal.indicators.williamsR > -20 ? (isBuy ? "text-primary font-bold" : "text-destructive font-bold") : "text-foreground"}>
                {signal.indicators.williamsR.toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-muted-foreground">BB {isBuy ? 'Lower' : 'Upper'}</span>
              <span className="text-foreground">{(isBuy ? signal.indicators.bollinger.lower : signal.indicators.bollinger.upper).toFixed(5)}</span>
            </div>
          </div>

          {signal.enterTime && (
            <div className="mt-4 p-3 bg-primary/5 rounded-md border border-primary/20">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span>ENTER AT:</span>
                </div>
                <span className="font-mono text-primary font-bold">{format(signal.enterTime, "HH:mm:ss")}</span>
              </div>
            </div>
          )}

          <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground border-t border-white/5 pt-3">
             <div className="flex items-center gap-1">
                <Timer className="h-3 w-3" />
                <span>{signal.status === "PENDING" ? "ENTER NOW" : signal.status}</span>
             </div>
             <div className={`font-mono ${isBuy ? 'text-primary' : 'text-destructive'}`}>
                ID: {signal.id.slice(0, 8)}
             </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
