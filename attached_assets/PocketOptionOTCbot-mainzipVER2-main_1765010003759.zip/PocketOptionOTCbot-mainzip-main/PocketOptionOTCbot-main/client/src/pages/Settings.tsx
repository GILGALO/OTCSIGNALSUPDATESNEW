
import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Settings as SettingsIcon, Key, CheckCircle, AlertCircle, Save, Clock } from "lucide-react";
import cyberBg from "@/assets/bg.png";

export default function Settings() {
  const { toast } = useToast();
  const [ssid, setSsid] = useState("");
  const [currentSsid, setCurrentSsid] = useState("");
  const [ssidStatus, setSsidStatus] = useState<"active" | "expired" | "unknown">("unknown");
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState<string>("");

  useEffect(() => {
    // Load current SSID from backend
    fetch("/api/settings/ssid")
      .then(res => res.json())
      .then(data => {
        if (data.ssid) {
          setCurrentSsid(data.ssid);
          setSsid(data.ssid);
          setSsidStatus(data.status || "unknown");
          if (data.lastUpdated) {
            setLastUpdated(new Date(data.lastUpdated));
          }
        }
      })
      .catch(err => console.error("Failed to load SSID:", err));

    // Check SSID status periodically
    const interval = setInterval(checkSsidStatus, 60000); // Check every minute
    return () => clearInterval(interval);
  }, []);

  // Calculate time remaining until expiry
  useEffect(() => {
    if (!lastUpdated) {
      setTimeRemaining("");
      return;
    }

    const updateTimer = () => {
      const now = new Date();
      const expiryTime = new Date(lastUpdated.getTime() + 48 * 60 * 60 * 1000); // 48 hours from last update
      const diff = expiryTime.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeRemaining("EXPIRED");
        setSsidStatus("expired");
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeRemaining(`${hours}h ${minutes}m ${seconds}s`);

      // Warn if less than 6 hours remaining
      if (hours < 6 && hours >= 0 && minutes === 0 && seconds === 0) {
        toast({
          title: "SSID Expiring Soon",
          description: `Your SSID will expire in ${hours} hours. Update it to continue receiving live prices.`,
          variant: "destructive",
        });
      }
    };

    updateTimer();
    const timer = setInterval(updateTimer, 1000);
    return () => clearInterval(timer);
  }, [lastUpdated, toast]);

  const checkSsidStatus = async () => {
    try {
      const res = await fetch("/api/settings/ssid/status");
      const data = await res.json();
      setSsidStatus(data.status);
      
      if (data.status === "expired") {
        toast({
          title: "SSID Expired",
          description: "Your Pocket Option SSID has expired. Please update it in Settings.",
          variant: "destructive",
        });
      }
    } catch (err) {
      console.error("Failed to check SSID status:", err);
    }
  };

  const handleSaveSsid = async () => {
    if (!ssid.trim()) {
      toast({
        title: "Invalid SSID",
        description: "Please enter a valid SSID",
        variant: "destructive",
      });
      return;
    }

    setIsSaving(true);
    try {
      const res = await fetch("/api/settings/ssid", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ssid: ssid.trim() }),
      });

      const data = await res.json();

      if (res.ok) {
        setCurrentSsid(ssid.trim());
        setSsidStatus(data.status);
        setLastUpdated(new Date());
        
        toast({
          title: "SSID Updated",
          description: "Your Pocket Option SSID has been saved successfully. Reconnecting to live prices...",
          className: "border-primary text-primary",
        });
      } else {
        throw new Error(data.error || "Failed to save SSID");
      }
    } catch (err: any) {
      toast({
        title: "Save Failed",
        description: err.message || "Unable to save SSID. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const getStatusBadge = () => {
    switch (ssidStatus) {
      case "active":
        return (
          <Badge className="bg-primary/20 text-primary border-primary/50">
            <CheckCircle className="h-3 w-3 mr-1" />
            Active
          </Badge>
        );
      case "expired":
        return (
          <Badge variant="destructive">
            <AlertCircle className="h-3 w-3 mr-1" />
            Expired
          </Badge>
        );
      default:
        return (
          <Badge variant="secondary">
            Unknown
          </Badge>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden font-sans">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
        <img src={cyberBg} alt="background" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-white/5 bg-background/50 backdrop-blur-md sticky top-0">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 bg-primary/20 rounded flex items-center justify-center border border-primary/50">
              <SettingsIcon className="h-5 w-5 text-primary" />
            </div>
            <h1 className="text-2xl font-display font-bold tracking-wider text-white">
              SETTINGS
            </h1>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-6 py-8 max-w-4xl">
        <Card className="bg-card/40 backdrop-blur-sm border-white/5">
          <div className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <Key className="h-6 w-6 text-primary" />
              <h2 className="text-xl font-display font-bold">Pocket Option SSID</h2>
            </div>

            <div className="space-y-6">
              {/* Current Status */}
              <div className="flex items-center justify-between p-4 bg-background/50 rounded-lg border border-white/5">
                <div>
                  <p className="text-sm text-muted-foreground">Connection Status</p>
                  <p className="text-lg font-mono mt-1">
                    {currentSsid ? `${currentSsid.substring(0, 8)}...` : "Not configured"}
                  </p>
                </div>
                {getStatusBadge()}
              </div>

              {/* Expiry Countdown Box */}
              {lastUpdated && (
                <div className={`p-4 rounded-lg border ${timeRemaining === "EXPIRED" ? "bg-destructive/10 border-destructive/50" : timeRemaining.startsWith("0h") || timeRemaining.split('h')[0] < "6" ? "bg-yellow-500/10 border-yellow-500/50" : "bg-primary/10 border-primary/50"}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Clock className={`h-5 w-5 ${timeRemaining === "EXPIRED" ? "text-destructive" : timeRemaining.startsWith("0h") || parseInt(timeRemaining.split('h')[0]) < 6 ? "text-yellow-500" : "text-primary"}`} />
                      <div>
                        <p className="text-sm font-display font-bold">
                          {timeRemaining === "EXPIRED" ? "SSID EXPIRED" : "Time Until Expiry"}
                        </p>
                        <p className="text-xs text-muted-foreground">SSIDs expire after 48 hours</p>
                      </div>
                    </div>
                    <div className={`text-2xl font-mono font-bold ${timeRemaining === "EXPIRED" ? "text-destructive" : timeRemaining.startsWith("0h") || parseInt(timeRemaining.split('h')[0]) < 6 ? "text-yellow-500" : "text-primary"}`}>
                      {timeRemaining === "EXPIRED" ? "00h 00m 00s" : timeRemaining}
                    </div>
                  </div>
                  {timeRemaining !== "EXPIRED" && (parseInt(timeRemaining.split('h')[0]) < 6) && (
                    <p className="text-xs text-yellow-500 mt-2">⚠ Warning: Update your SSID soon to avoid service interruption</p>
                  )}
                  {timeRemaining === "EXPIRED" && (
                    <p className="text-xs text-destructive mt-2">⚠ Update your SSID immediately to restore live price functionality</p>
                  )}
                </div>
              )}

              {/* Last Updated */}
              {lastUpdated && (
                <div className="p-4 bg-background/50 rounded-lg border border-white/5">
                  <p className="text-sm text-muted-foreground">Last Updated</p>
                  <p className="text-lg font-mono mt-1">
                    {lastUpdated.toLocaleString()}
                  </p>
                </div>
              )}

              {/* SSID Input */}
              <div className="space-y-3">
                <Label htmlFor="ssid" className="text-sm font-display">
                  Update SSID
                </Label>
                <Input
                  id="ssid"
                  type="text"
                  value={ssid}
                  onChange={(e) => setSsid(e.target.value)}
                  placeholder="Enter your Pocket Option SSID"
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground">
                  Your SSID can be found in your browser's developer tools under Application → Cookies → ssid
                </p>
              </div>

              {/* Save Button */}
              <Button
                onClick={handleSaveSsid}
                disabled={isSaving || !ssid.trim() || ssid.trim() === currentSsid}
                className="w-full bg-primary hover:bg-primary/90"
              >
                {isSaving ? (
                  <>Saving...</>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save SSID
                  </>
                )}
              </Button>

              {/* Info Box */}
              <div className="p-4 bg-primary/10 rounded-lg border border-primary/20">
                <h3 className="font-display font-bold text-sm mb-2 text-primary">Important Notes</h3>
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li>• SSIDs expire after exactly 48 hours</li>
                  <li>• You'll see a countdown timer above showing time remaining</li>
                  <li>• You'll receive warnings when less than 6 hours remain</li>
                  <li>• Live prices will stop working with an expired SSID</li>
                  <li>• Update your SSID here before expiry to maintain functionality</li>
                </ul>
              </div>
            </div>
          </div>
        </Card>
      </main>
    </div>
  );
}
