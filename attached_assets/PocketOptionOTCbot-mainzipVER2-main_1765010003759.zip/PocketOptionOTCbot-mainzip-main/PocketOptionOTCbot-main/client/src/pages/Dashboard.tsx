import { SignalCard } from "@/components/SignalCard";
import { StatsPanel } from "@/components/StatsPanel";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { Zap, BarChart3, Globe, RefreshCw, Scan, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSignals, useMarketData, useGenerateSignal, useStats, useAutoGenerationStatus, useToggleAutoGeneration } from "@/lib/api";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";
import cyberBg from "@/assets/bg.png";

export default function Dashboard() {
  const { toast } = useToast();
  
  const { data: signals = [], refetch: refetchSignals } = useSignals(50);
  const { data: marketData = [], refetch: refetchMarket } = useMarketData();
  const { data: stats } = useStats();
  const { data: autoGenStatus } = useAutoGenerationStatus();
  const generateSignalMutation = useGenerateSignal();
  const toggleAutoGenMutation = useToggleAutoGeneration();

  const isAutoEnabled = autoGenStatus?.autoGenerationEnabled ?? true;

  const refreshData = () => {
    refetchMarket();
    refetchSignals();
    toast({
      title: "Data Refreshed",
      description: "Market prices and indicators updated.",
    });
  };

  const handleAutoToggle = async (enabled: boolean) => {
    try {
      await toggleAutoGenMutation.mutateAsync(enabled);
      toast({
        title: enabled ? "Auto-Generation Enabled" : "Auto-Generation Disabled",
        description: enabled 
          ? "Signals will be generated every 7 minutes with 3-minute preparation"
          : "Automatic signal generation has been stopped",
      });
    } catch (error) {
      toast({
        title: "Toggle Failed",
        description: "Unable to toggle auto-generation. Please try again.",
        variant: "destructive",
      });
    }
  };

  const triggerManualScan = async () => {
    toast({
      title: "Initiating Manual Scan",
      description: "Analyzing all pairs for High Precision setups...",
    });

    try {
      const result = await generateSignalMutation.mutateAsync();
      
      toast({
        title: "Signal Found!",
        description: `New setup detected on ${result.signal.pair}`,
        className: "border-primary text-primary",
      });

      if (result.telegramSent) {
        toast({
          title: "Telegram Notification Sent",
          description: "Signal delivered to your channel successfully!",
          duration: 3000,
        });
      }
    } catch (error) {
      toast({
        title: "Scan Failed",
        description: "Unable to generate signal. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden font-sans">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0 opacity-20 pointer-events-none">
         <img src={cyberBg} alt="background" className="w-full h-full object-cover" />
         <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-white/5 bg-background/50 backdrop-blur-md sticky top-0">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 bg-primary/20 rounded flex items-center justify-center border border-primary/50">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <h1 className="text-2xl font-display font-bold tracking-wider text-white">
              SIGNAL<span className="text-primary">BOT</span> <span className="text-xs text-muted-foreground font-normal ml-2 border border-white/10 px-2 py-0.5 rounded">v2.4 OTC</span>
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 border border-white/10 rounded-lg px-3 py-1.5 bg-card/20">
              <Label htmlFor="auto-toggle" className="text-xs font-mono cursor-pointer text-muted-foreground">
                AUTO
              </Label>
              <Switch 
                id="auto-toggle"
                checked={isAutoEnabled}
                onCheckedChange={handleAutoToggle}
                disabled={toggleAutoGenMutation.isPending}
                className="data-[state=checked]:bg-primary"
              />
              <span className={`text-xs font-bold ${isAutoEnabled ? 'text-primary' : 'text-muted-foreground'}`}>
                {isAutoEnabled ? 'ON' : 'OFF'}
              </span>
            </div>

            <Button 
              variant="outline" 
              size="sm" 
              onClick={triggerManualScan}
              disabled={generateSignalMutation.isPending}
              className="border-primary/50 text-primary hover:bg-primary/10 hover:text-primary hidden md:flex"
            >
              {generateSignalMutation.isPending ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Scan className="mr-2 h-4 w-4" />
              )}
              {generateSignalMutation.isPending ? "SCANNING..." : "MANUAL SCAN"}
            </Button>

            <Button 
              variant="ghost" 
              size="icon" 
              onClick={refreshData}
              className="text-muted-foreground hover:text-foreground"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>

            <Link href="/settings">
              <Button 
                variant="ghost" 
                size="icon"
                className="text-muted-foreground hover:text-foreground"
              >
                <Settings className="h-4 w-4" />
              </Button>
            </Link>

            <div className="h-8 w-px bg-white/10" />
            
            <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground hidden sm:flex">
              <Globe className="h-3 w-3" />
              <span>GMT-4 (NY)</span>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-6 py-8">
        <StatsPanel />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Signal Feed */}
          <div className="lg:col-span-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <h2 className="text-xl font-display font-bold flex items-center gap-2">
                  <div className="h-2 w-2 bg-primary rounded-full animate-pulse" />
                  LIVE SIGNALS
                </h2>
                <Badge variant="secondary" className="font-mono hidden sm:inline-flex">LIVE FEED</Badge>
              </div>
              <Button 
                size="sm" 
                className="md:hidden bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20"
                onClick={triggerManualScan}
                disabled={generateSignalMutation.isPending}
              >
                {generateSignalMutation.isPending ? <RefreshCw className="h-4 w-4 animate-spin" /> : "SCAN"}
              </Button>
            </div>

            <div className="space-y-4">
              <AnimatePresence mode="popLayout">
                {signals.length === 0 ? (
                  <div className="text-center py-12 bg-card/40 backdrop-blur-sm border border-white/5 rounded-lg">
                    <div className="text-muted-foreground">
                      <Scan className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p className="text-lg font-display">NO ACTIVE SIGNALS</p>
                      <p className="text-sm mt-2">Signals generate automatically every 7 minutes</p>
                      <p className="text-xs mt-1 text-primary">Click MANUAL SCAN to generate one now</p>
                    </div>
                  </div>
                ) : (
                  signals.map((signal: any) => (
                    <SignalCard 
                      key={signal.signalId} 
                      signal={{
                        id: signal.signalId,
                        pair: signal.pair,
                        direction: signal.direction,
                        timestamp: new Date(signal.timestamp),
                        expiry: new Date(signal.expiryTime),
                        confidence: signal.confidence,
                        payout: signal.payout,
                        indicators: signal.indicators,
                        status: signal.status,
                        prepareTime: signal.prepareTime ? new Date(signal.prepareTime) : undefined,
                        enterTime: signal.enterTime ? new Date(signal.enterTime) : undefined,
                      }} 
                    />
                  ))
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Sidebar: Market Watch */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-card/40 backdrop-blur-sm border border-white/5 rounded-lg overflow-hidden">
              <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <h3 className="font-display font-bold text-sm">MARKET WATCH</h3>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </div>
              <ScrollArea className="h-[600px]">
                <div className="p-2 space-y-1">
                  {marketData.map((pair) => (
                    <div key={pair.name} className="flex items-center justify-between p-3 hover:bg-white/5 rounded transition-colors cursor-pointer group">
                      <div className="flex flex-col">
                        <span className="font-bold font-display text-sm group-hover:text-primary transition-colors">{pair.name}</span>
                        <span className="text-xs text-muted-foreground font-mono">{pair.payout}% Payout</span>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="font-mono text-sm">{pair.price.toFixed(5)}</span>
                        <span className={`text-xs font-mono ${pair.change >= 0 ? "text-primary" : "text-destructive"}`}>
                          {pair.change >= 0 ? "+" : ""}{pair.change.toFixed(4)}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>

            <div className="bg-card/40 backdrop-blur-sm border border-white/5 rounded-lg p-6 space-y-4">
              <h3 className="font-display font-bold text-sm text-muted-foreground uppercase tracking-widest">Active Strategy</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm border-b border-white/5 pb-2">
                  <span className="text-muted-foreground">Type</span>
                  <span className="font-mono text-foreground">Reversal</span>
                </div>
                <div className="flex justify-between text-sm border-b border-white/5 pb-2">
                  <span className="text-muted-foreground">Indicators</span>
                  <span className="font-mono text-foreground">BB(20,2) + RSI(14) + W%R</span>
                </div>
                <div className="flex justify-between text-sm border-b border-white/5 pb-2">
                  <span className="text-muted-foreground">Timeframe</span>
                  <span className="font-mono text-foreground">M1 Analysis &rarr; M5 Expiry</span>
                </div>
                <div className="flex justify-between text-sm pt-2">
                  <span className="text-muted-foreground">Mode</span>
                  <span className="font-mono text-primary">Strict Confluence</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
