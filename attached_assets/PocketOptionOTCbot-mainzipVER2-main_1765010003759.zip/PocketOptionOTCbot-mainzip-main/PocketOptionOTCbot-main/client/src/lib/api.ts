import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export interface Signal {
  id: number;
  signalId: string;
  pair: string;
  direction: "BUY" | "SELL";
  timestamp: string;
  expiryTime: string;
  confidence: number;
  payout: number;
  entryPrice: number | null;
  exitPrice: number | null;
  indicators: {
    rsi: number;
    williamsR: number;
    bollinger: {
      upper: number;
      lower: number;
      current: number;
    };
  };
  status: "PENDING" | "WON" | "LOST";
  sentToTelegram: boolean;
}

export interface Stats {
  id: number;
  wins: number;
  losses: number;
  todayWins: number;
  todayLosses: number;
  lastUpdated: string;
}

export interface MarketPair {
  name: string;
  payout: number;
  price: number;
  change: number;
}

// API Functions
async function fetchSignals(limit: number = 50): Promise<Signal[]> {
  const response = await fetch(`/api/signals?limit=${limit}`);
  if (!response.ok) throw new Error('Failed to fetch signals');
  return response.json();
}

async function fetchStats(): Promise<Stats> {
  const response = await fetch('/api/stats');
  if (!response.ok) throw new Error('Failed to fetch stats');
  return response.json();
}

async function fetchMarketData(): Promise<MarketPair[]> {
  const response = await fetch('/api/market');
  if (!response.ok) throw new Error('Failed to fetch market data');
  return response.json();
}

async function generateSignal(): Promise<{ signal: Signal; telegramSent: boolean }> {
  const response = await fetch('/api/signals/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  });
  if (!response.ok) throw new Error('Failed to generate signal');
  return response.json();
}

async function toggleAutoGeneration(enabled: boolean): Promise<{ success: boolean; autoGenerationEnabled: boolean }> {
  const response = await fetch('/api/auto-generation/toggle', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ enabled }),
  });
  if (!response.ok) throw new Error('Failed to toggle auto-generation');
  return response.json();
}

async function getAutoGenerationStatus(): Promise<{ autoGenerationEnabled: boolean }> {
  const response = await fetch('/api/auto-generation/status');
  if (!response.ok) throw new Error('Failed to fetch auto-generation status');
  return response.json();
}

// React Query Hooks
export function useSignals(limit: number = 50) {
  return useQuery({
    queryKey: ['signals', limit],
    queryFn: () => fetchSignals(limit),
    refetchInterval: 5000, // Refetch every 5 seconds for live updates
  });
}

export function useStats() {
  return useQuery({
    queryKey: ['stats'],
    queryFn: fetchStats,
    refetchInterval: 10000, // Refetch every 10 seconds
  });
}

export function useMarketData() {
  return useQuery({
    queryKey: ['market'],
    queryFn: fetchMarketData,
    refetchInterval: 3000, // Refetch every 3 seconds
  });
}

export function useGenerateSignal() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: generateSignal,
    onSuccess: () => {
      // Invalidate and refetch signals and stats
      queryClient.invalidateQueries({ queryKey: ['signals'] });
      queryClient.invalidateQueries({ queryKey: ['stats'] });
    },
  });
}

export function useAutoGenerationStatus() {
  return useQuery({
    queryKey: ['autoGeneration'],
    queryFn: getAutoGenerationStatus,
    refetchInterval: 5000,
  });
}

export function useToggleAutoGeneration() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: toggleAutoGeneration,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['autoGeneration'] });
    },
  });
}
