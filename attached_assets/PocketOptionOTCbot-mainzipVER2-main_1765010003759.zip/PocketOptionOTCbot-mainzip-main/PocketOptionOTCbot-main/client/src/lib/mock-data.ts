import { subMinutes, format } from "date-fns";

export interface Signal {
  id: string;
  pair: string;
  direction: "BUY" | "SELL";
  timestamp: Date;
  expiry: Date;
  confidence: number;
  payout: number;
  indicators: {
    rsi: number;
    williamsR: number;
    bollinger: {
      upper: number;
      lower: number;
      current: number;
    };
  };
  status: "PENDING" | "WON" | "LOST";
}

export interface MarketPair {
  name: string;
  payout: number;
  price: number;
  change: number;
}

const PAIRS = [
  "EURUSD_OTC", "USDJPY_OTC", "GBPJPY_OTC", "AUDCHF_OTC",
  "EURJPY_OTC", "NZDUSD_OTC", "AUDUSD_OTC", "GBPUSD_OTC", "USDCHF_OTC"
];

const PAYOUTS: Record<string, number> = {
  'EURUSD_OTC': 82, 'USDJPY_OTC': 81, 'GBPJPY_OTC': 78,
  'AUDCHF_OTC': 76, 'EURJPY_OTC': 79, 'NZDUSD_OTC': 77,
  'AUDUSD_OTC': 80, 'GBPUSD_OTC': 83, 'USDCHF_OTC': 82
};

export const generateMockSignal = (): Signal => {
  const pair = PAIRS[Math.floor(Math.random() * PAIRS.length)];
  const now = new Date();
  const isHighPrecision = Math.random() > 0.3; // 70% chance of high precision
  
  // Mock indicator values that would trigger a signal based on the python script
  // RSI < 40 for BUY
  const rsi = 25 + Math.random() * 15;
  const williamsR = -80 - Math.random() * 20;
  
  return {
    id: Math.random().toString(36).substring(7),
    pair,
    direction: "BUY", // Script focuses on BUY signals
    timestamp: now,
    expiry: new Date(now.getTime() + 5 * 60000), // 5 min expiry
    confidence: isHighPrecision ? 85 + Math.floor(Math.random() * 15) : 70 + Math.floor(Math.random() * 10),
    payout: PAYOUTS[pair] || 80,
    indicators: {
      rsi,
      williamsR,
      bollinger: {
        upper: 1.1000 + Math.random() * 0.01,
        lower: 1.0900 - Math.random() * 0.01,
        current: 1.0900 - Math.random() * 0.005, // Below lower band
      }
    },
    status: "PENDING"
  };
};

export const generateMarketData = (): MarketPair[] => {
  return PAIRS.map(pair => ({
    name: pair,
    payout: PAYOUTS[pair] || 80,
    price: 1.0 + Math.random() * 0.5,
    change: (Math.random() - 0.5) * 0.01
  }));
};

export const getMockStats = () => {
  return {
    wins: 142,
    losses: 23,
    winRate: 86.1,
    totalSignals: 165,
    todayWins: 12,
    todayLosses: 1
  };
};
