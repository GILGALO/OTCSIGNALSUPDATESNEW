import { pgTable, text, serial, timestamp, integer, boolean, doublePrecision, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const signals = pgTable("signals", {
  id: serial("id").primaryKey(),
  signalId: text("signal_id").notNull().unique(),
  pair: text("pair").notNull(),
  direction: text("direction").notNull(),
  confidence: integer("confidence").notNull(),
  payout: integer("payout").notNull(),
  entryPrice: doublePrecision("entry_price"),
  exitPrice: doublePrecision("exit_price"),
  indicators: jsonb("indicators").notNull(),
  status: text("status").notNull().default("PENDING"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  expiryTime: timestamp("expiry_time").notNull(),
  sentToTelegram: boolean("sent_to_telegram").notNull().default(false),
});

export const stats = pgTable("stats", {
  id: serial("id").primaryKey(),
  wins: integer("wins").notNull().default(0),
  losses: integer("losses").notNull().default(0),
  todayWins: integer("today_wins").notNull().default(0),
  todayLosses: integer("today_losses").notNull().default(0),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const marketData = pgTable("market_data", {
  id: serial("id").primaryKey(),
  pair: text("pair").notNull(),
  payout: integer("payout").notNull(),
  price: doublePrecision("price").notNull(),
  change: doublePrecision("change").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const ssidSettings = pgTable("ssid_settings", {
  id: serial("id").primaryKey(),
  ssid: text("ssid").notNull(),
  status: text("status").notNull().default("active"),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertSignalSchema = createInsertSchema(signals).omit({
  id: true,
  timestamp: true,
});

export const insertStatsSchema = createInsertSchema(stats).omit({
  id: true,
  lastUpdated: true,
});

export type Signal = typeof signals.$inferSelect;
export type InsertSignal = z.infer<typeof insertSignalSchema>;
export type Stats = typeof stats.$inferSelect;
export type InsertStats = z.infer<typeof insertStatsSchema>;